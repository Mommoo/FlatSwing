package util;

import flat.textfield.FlatTextField;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KeyManager {

	private static final String SAVE_KEY = "save";
	private static final String LIST_KEY = "list";
	private static final String SEARCH_KEY = "search";
	private static final String ENTER_KEY = "enter";

	@Deprecated
	public interface Enter{
		public void execute();
	}

	public interface KeyEventListener{
		public void execute();
	}

	@Deprecated
	public static void addEnterKeyListener(Enter enter,FlatTextField... flatTextFields){
		for(FlatTextField flatTextField : flatTextFields){
			flatTextField.addKeyListener(new KeyAdapter(){
				@Override
				public void keyReleased(KeyEvent e) {
					if(e.getKeyChar()==KeyEvent.VK_ENTER){
						enter.execute();
					}
				} 
			});
		}
	}

	public static void addEnterKeyListener(JComponent comp, final KeyEventListener listener){
		comp.addKeyListener(new KeyAdapter(){
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER){
					listener.execute();
				}
			}
		});
	}

	@Deprecated
	public static void addEnterKeyListener(Enter enter,JPanel jPanel){
		KeyStroke keyStroke = KeyStroke.getKeyStroke((char)KeyEvent.VK_ENTER);
		jPanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStroke, "ENTER");
		jPanel.getActionMap().put("ENTER", new AbstractAction("Enter"){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				enter.execute();
			}
		});
	}

	public static void addEnterKeyListener(JFrame rootFrame, final KeyEventListener listener){
		final JRootPane ROOT_PANE = rootFrame.getRootPane();
		ROOT_PANE.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke((char)KeyEvent.VK_ENTER),ENTER_KEY);
		ROOT_PANE.getActionMap().put(ENTER_KEY, new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (listener != null) listener.execute();
			}
		});
	}

	public static void addEnterKeyListener(Enter enter,Component component){
		component.addKeyListener(new KeyAdapter(){
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyChar()==KeyEvent.VK_ENTER){
					enter.execute();
				}
			}
		});
	}

	public static void registerSaveKeyListener(JFrame rootFrame , final KeyEventListener LISTENER){
		final JRootPane ROOT_PANE = rootFrame.getRootPane();
		ROOT_PANE.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke((char)KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK),SAVE_KEY);
		ROOT_PANE.getActionMap().put(SAVE_KEY, new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (LISTENER != null) LISTENER.execute();
			}
		});

	}

	public static void registerListKeyListener(JFrame rootFrame, final KeyEventListener listener){
		final JRootPane ROOT_PANE = rootFrame.getRootPane();
		ROOT_PANE.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke((char)KeyEvent.VK_L, InputEvent.CTRL_DOWN_MASK),LIST_KEY);
		ROOT_PANE.getActionMap().put(LIST_KEY, new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (listener != null) listener.execute();
			}
		});
	}

	public static void registerSearchKeyListener(JFrame rootFrame, final KeyEventListener listener){
		final JRootPane ROOT_PANE = rootFrame.getRootPane();
		ROOT_PANE.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke((char)KeyEvent.VK_F, InputEvent.CTRL_DOWN_MASK),SEARCH_KEY);
		ROOT_PANE.getActionMap().put(SEARCH_KEY, new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (listener != null) listener.execute();
			}
		});
	}
}
