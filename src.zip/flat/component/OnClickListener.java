package flat.component;

public interface OnClickListener {
	public void onClick(Object c);
}
