package flat.component;

public interface OnPositionClickListener {
	public void onClick(int position, Object target);
}
