package flat.frame.titlebar.navigation.controller;


import flat.frame.titlebar.navigation.button.NavigationButton;
import flat.frame.titlebar.navigation.button.NavigationButtonFactory;
import flat.frame.titlebar.navigation.button.NavigationButtonType;
import flat.frame.titlebar.navigation.listener.NavigationControlListener;
import util.ScreenManager;

import javax.swing.*;
import java.awt.*;

/**
 * Created by mommoo on 2017-07-10.
 */
public class NavigationControlPanel extends JPanel {
    private static final ScreenManager SCREEN_MANAGER = ScreenManager.getInstance();
    private static final int GAP = SCREEN_MANAGER.dip2px(5);

    private final NavigationButton[] NAVIGATION_BTN_ARRAY = NavigationButtonFactory.createNavigationButtonArray();

    public NavigationControlPanel(int titleBarHeight) {
        setLayout(new GridLayout(0, NAVIGATION_BTN_ARRAY.length, GAP, GAP));
        Dimension buttonDimen = new Dimension((int)(titleBarHeight*1.5), titleBarHeight);
        setMinimumSize(new Dimension((buttonDimen.width * NAVIGATION_BTN_ARRAY.length) + (GAP * (NAVIGATION_BTN_ARRAY.length - 1)), -1));
        addNavigationButtons(buttonDimen);
        setTransparent();
    }

    private void addNavigationButtons(Dimension buttonDimen) {
        for (Component comp : NAVIGATION_BTN_ARRAY) {
            comp.setPreferredSize(buttonDimen);
            comp.setMinimumSize(buttonDimen);
            add(comp);
        }
    }

    private void setTransparent() {
        setOpaque(false);
    }

    public void setThemeColor(Color color){
        for (NavigationButton navigationButton : NAVIGATION_BTN_ARRAY){
            navigationButton.setBackground(color);
            navigationButton.setFocusColor(color.darker(), color);
        }

        setExitButtonThemeColor(color);
    }

    private void setExitButtonThemeColor(Color color){
        NAVIGATION_BTN_ARRAY[2].setFocusColor(Color.RED.darker(), color);
        Color originalMenuIconColor = NAVIGATION_BTN_ARRAY[2].getMenuIconColor();
        NAVIGATION_BTN_ARRAY[2].setFocusGainListener(()-> NAVIGATION_BTN_ARRAY[2].setMenuIconColor(Color.WHITE));
        NAVIGATION_BTN_ARRAY[2].setFocusLostListener(()-> NAVIGATION_BTN_ARRAY[2].setMenuIconColor(originalMenuIconColor));
    }

    public void setOnControlListener(NavigationControlListener controlListener) {
        NavigationButtonType[] buttonTypes = NavigationButtonType.values();

        for (int i = 0 , size = NAVIGATION_BTN_ARRAY.length ; i < size ; i++){
            NavigationButtonType buttonType = buttonTypes[i];
            NAVIGATION_BTN_ARRAY[i].addActionListener(event -> controlListener.onNavigationClick(buttonType));
        }
    }
}
