package flat.frame.titlebar.navigation.listener;


import flat.frame.titlebar.navigation.button.NavigationButtonType;

/**
 * Created by mommoo on 2017-07-13.
 */
public interface NavigationControlListener {
    public void onNavigationClick(NavigationButtonType buttonType);
}
