package flat.frame.titlebar.navigation.listener;

/**
 * Created by mommoo on 2017-07-13.
 */
public interface FocusGainListener {
    public void gain();
}
