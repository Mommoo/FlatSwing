package flat.frame.titlebar.navigation.listener;

public interface FocusLostListener {
    public void lost();
}
