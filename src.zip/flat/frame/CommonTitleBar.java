package flat.frame;

import flat.component.FlatPanel;
import flat.frame.titlebar.TitleLabel;
import flat.frame.titlebar.navigation.controller.NavigationControlPanel;
import flat.image.FlatImagePanel;
import flat.image.ImageOption;
import util.ImageManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

class CommonTitleBar extends FlatPanel {
	private static final int TITLE_BAR_HEIGHT = 50;
	private static final int TITLE_BAR_LEFT_PADDING = 10;
	private static final int TITLE_TEXT_FONT_SIZE = TITLE_BAR_HEIGHT/3;

	private static final GridBagConstraints GRID_BAG_CONSTRAINTS = new GridBagConstraints();



	private final TitleLabel TITLE_LABEL = new TitleLabel(TITLE_TEXT_FONT_SIZE);
	private final NavigationControlPanel controlPanel = new NavigationControlPanel(3*TITLE_BAR_HEIGHT/5);

	private FlatImagePanel mainIcon;
	
	private boolean isClickedSizeBtn;
	
	private final Dimension BEFORE_DIMENSION = new Dimension();
	private final Point BEFORE_POINT = new Point();

	private boolean windowExit;

	private boolean isEnableSizeButton;

	CommonTitleBar() {
		setLayout(new GridBagLayout());
		setBorder(BorderFactory.createEmptyBorder(0,TITLE_BAR_LEFT_PADDING,0,10));
		createMainIcon();
		addTitleLabel();
		addControllerPanel();
		setControlListener();
	}

	private void createMainIcon(){
		Dimension mainIconDimen = new Dimension(3*TITLE_BAR_HEIGHT/5, 3*TITLE_BAR_HEIGHT/5);
		mainIcon = new FlatImagePanel();
		mainIcon.setPreferredSize(mainIconDimen);
		mainIcon.setMinimumSize(mainIconDimen);
	}
	
	private void addTitleLabel(){
		GRID_BAG_CONSTRAINTS.fill = GridBagConstraints.BOTH;
		addComponent(TITLE_LABEL,GRID_BAG_CONSTRAINTS,1,0,1,1,1,0);
	}
	
	private void addControllerPanel(){
		GRID_BAG_CONSTRAINTS.fill = GridBagConstraints.BOTH;
		addComponent(controlPanel,GRID_BAG_CONSTRAINTS,2,0,1,1,0,0);
	}
	
	private void addComponent(JComponent jComponent, final GridBagConstraints gbc, 
			int gridX, int gridY, int gridWidth, int gridHeight, double weightX, double weightY){
		gbc.gridx = gridX;
		gbc.gridy = gridY;
		gbc.gridwidth = gridWidth;
		gbc.gridheight = gridHeight;
		gbc.weightx = weightX;
		gbc.weighty = weightY;
		this.add(jComponent,gbc);
	}
	
	void setTitle(String title){
		TITLE_LABEL.setText(title);
	}
	
	String getTitle(){
		return TITLE_LABEL.getText();
	}
	
	void setIconImage(Image image){
		mainIcon.setIcon(image, ImageOption.MATCH_PARENT);
		if (!isComponentContained(mainIcon)){
			addComponent(mainIcon,GRID_BAG_CONSTRAINTS,0,0,1,1,0,0);
		}
	}

	void removeIconImage(){
		if (isComponentContained(mainIcon)) remove(mainIcon);
	}

	void setThemeColor(Color color){
		super.setBackground(color);
		mainIcon.setBackground(color);
		controlPanel.setThemeColor(color);
	}
	
	Color getThemeColor(){
		return super.getBackground();
	}

	void setMenuButtonColor(Color color){
//		for(NavigationButton btn : NAVIGATION_BTN_ARRAY){
//			btn.setMenuIconColor(color);
//		}
	}

	Color getMenuButtonColor(){
//		return NAVIGATION_BTN_ARRAY[0].getMenuIconColor();
		return Color.RED;
	}
	
	void setTitleColor(Color color){
		TITLE_LABEL.setForeground(color);
	}
	
	Color getTitleColor(){
		return TITLE_LABEL.getForeground();
	}
	
	void setWindowExit(boolean isWindowExit){
		this.windowExit = isWindowExit;
	}

	void setEnableSizeButton(boolean enableSizeButton){
		this.isEnableSizeButton = enableSizeButton;
	}

	void removeControlPanel(){
		remove(controlPanel);
	}


	public void mouseReleased(MouseEvent e) {

//		else if (isEnableSizeButton && comp == NAVIGATION_BTN_ARRAY[1]){
//			if(isClickedSizeBtn){
//				PARENT_FRAME.setSize(BEFORE_DIMENSION);
//				PARENT_FRAME.setLocation(BEFORE_POINT);
//			}else{
//				BEFORE_DIMENSION.setSize(PARENT_FRAME.getSize());
//				BEFORE_POINT.setLocation(PARENT_FRAME.getLocation());
//				PARENT_FRAME.setSize(SCREEN_MANAGER.getWindowWidth(),SCREEN_MANAGER.getWindowHeight());
//				PARENT_FRAME.setLocation(0,0);
//			}
//			isClickedSizeBtn = !isClickedSizeBtn;
//		}
	}

	private void setControlListener(){
		this.controlPanel.setOnControlListener(buttonType -> {
			JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
			switch (buttonType){
				case MINI :
					parentFrame.setState(Frame.ICONIFIED);
					break;
				case SIZE :
					break;
				case EXIT :
					if (windowExit) System.exit(1);
					else parentFrame.dispose();
					break;
			}
		});
	}

	public static void main(String[] args){
		SwingUtilities.invokeLater(()->{
			FlatFrame f = new FlatFrame();
			f.setSize(700,500);
			f.setImageIcon(ImageManager.TEST);
			f.setTitle("A Beautiful Frame. You can custom you want!");
			f.setResizable(true);
			f.setLocationOnScreenCenter();
			f.show();
		});
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(super.getPreferredSize().width , TITLE_BAR_HEIGHT);
	}

	@Override
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	public static int getTitleBarHeight(){
		return TITLE_BAR_HEIGHT;
	}
}