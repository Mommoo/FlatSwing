package flat.frame;

import util.ImageManager;
import util.ScreenManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public final class FlatFrame {
	private static final Color DEFAULT_THEME_COLOR = Color.decode("#eeeeee");
	private final CommonJFrame COMMON_JFRAME = new CommonJFrame();
	private final CommonTitleBar TITLE_BAR = new CommonTitleBar();
	private final JPanel USER_CUSTOMIZABLE_PANEL = new JPanel();

	private int clickedX,clickedY;
	private boolean isCenterLocation;

	public FlatFrame() {
		setThemeColor(DEFAULT_THEME_COLOR);
		setLocation(0,0);
		initUserCustomizablePanel();
		addComponent();
		setTitleBarDragEvent();
		setImageIcon(ImageManager.TEST);
	}

	private void initUserCustomizablePanel(){
		USER_CUSTOMIZABLE_PANEL.setLayout(new BorderLayout());
	}
	
	private void addComponent(){
		JPanel customizablePanel = COMMON_JFRAME.getCustomizablePanel();
		customizablePanel.setLayout(new BorderLayout());
		customizablePanel.add(TITLE_BAR,BorderLayout.NORTH);
		customizablePanel.add(USER_CUSTOMIZABLE_PANEL,BorderLayout.CENTER);
		customizablePanel.setBorder(BorderFactory.createEmptyBorder(0,1,0,0));
	}
	
	private void setTitleBarDragEvent(){
		TITLE_BAR.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				clickedX = e.getX();
				clickedY = e.getY();
			}
		});
		
		TITLE_BAR.addMouseMotionListener(new MouseAdapter(){
			private int moveX,moveY;
			@Override
			public void mouseDragged(MouseEvent e){
				moveX = e.getX() - clickedX;
				moveY = e.getY() - clickedY;
				COMMON_JFRAME.setLocation(COMMON_JFRAME.getLocation().x + moveX,COMMON_JFRAME.getLocation().y + moveY);
			}
		});
	}

	public void setThemeColor(Color color){
		TITLE_BAR.setThemeColor(color);
		USER_CUSTOMIZABLE_PANEL.setBackground(color.brighter());
	}

	public JPanel getContainer() {
		return USER_CUSTOMIZABLE_PANEL;
	}

	public void setTitle(String title){
		TITLE_BAR.setTitle(title);
	}
	
	public String getTitle(){
		return TITLE_BAR.getTitle();
	}
	
	public void setTitleColor(Color color){
		TITLE_BAR.setTitleColor(color);
	}
	
	public Color getTitleColor(Color color){
		return TITLE_BAR.getTitleColor();
	}
	
	public static int getTitleBarHeight(){
		return CommonTitleBar.getTitleBarHeight();
	}
	
	public void setTitleBarColor(Color color){
		TITLE_BAR.setThemeColor(color);
	}

	public Color getTitleBarColor(){
		return TITLE_BAR.getThemeColor();
	}

	public void setMenuButtonColor(Color color){
		TITLE_BAR.setMenuButtonColor(color);
	}

	public Color getMenuButtonColor(){
		return TITLE_BAR.getMenuButtonColor();
	}
	
	public void setImageIcon(Image image){
		if (image == null) return;
		this.COMMON_JFRAME.setIconImage(image);
		this.TITLE_BAR.setIconImage(image);
	}

	public void removeImageIcon(){
		this.COMMON_JFRAME.setIconImage(null);
		this.TITLE_BAR.removeIconImage();
	}

	public void removeControlPanel(){
		this.TITLE_BAR.removeControlPanel();
	}
	
	public void setBorderColor(Color color) {
		this.COMMON_JFRAME.setBorderColor(color);
	}

	public Color getBorderColor() {
		return this.COMMON_JFRAME.getBorderColor();
	}
	
	public void setBorderStrokeWidth(int borderStrokeWidth){
		COMMON_JFRAME.setBorderStrokeWidth(borderStrokeWidth);
	}
	
	public int getBorderStrokeWidth(){
		return COMMON_JFRAME.getBorderStrokeWidth();
	}
	
	public void setShadowWidth(int shadowWidth){
		this.COMMON_JFRAME.setShadowWidth(shadowWidth);
	}
	
	public int getShadowWidth(){
		return COMMON_JFRAME.getShadowWidth();
	}
	
	public void setSize(int width,int height){
		COMMON_JFRAME.setSize(width,height);
	}
	
	public Dimension getSize(){
		return COMMON_JFRAME.getSize();
	}
	
	public void setLocation(int x, int y){
		this.COMMON_JFRAME.setLocation(x, y);
	}
	
	public Point getLocation(){
		return this.COMMON_JFRAME.getLocation();
	}

	public void setLocationOnScreenCenter(){
		isCenterLocation = true;
	}
	
	public void setWindowExit(boolean windowExit){
		this.TITLE_BAR.setWindowExit(windowExit);
	}
	
	public void setResizable(boolean reSizable){
		COMMON_JFRAME.setResizable(reSizable);
	}
	
	public boolean isResizable(){
		return COMMON_JFRAME.isResizable();
	}

	public void setAlwaysOnTop(boolean alwaysOnTop){
		COMMON_JFRAME.setAlwaysOnTop(alwaysOnTop);
	}

	public void setUtilityType(){
		COMMON_JFRAME.setType(JFrame.Type.UTILITY);
	}

	public void setEnableTitleBarMenuButton(int menuIndex,boolean isEnable){
		if(menuIndex == 1) TITLE_BAR.setEnableSizeButton(isEnable);
	}

	public JFrame getJFrame(){
		return COMMON_JFRAME;
	}
	
	public void show() {
		if (isCenterLocation) {
			ScreenManager screenManager = ScreenManager.getInstance();
			this.COMMON_JFRAME.setLocation((screenManager.getWindowWidth() - getSize().width )/2, (screenManager.getWindowHeight() - getSize().height)/2);
		}
		COMMON_JFRAME.setVisible(true);
	}
	
	public void hide(){
		COMMON_JFRAME.setVisible(false);
	}
}
