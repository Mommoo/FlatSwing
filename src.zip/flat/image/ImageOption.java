package flat.image;

public enum ImageOption{
    MATCH_PARENT,
    BASIC_IMAGE_SIZE,
    BASIC_IMAGE_SIZE_CENTER;
}
